package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//조건문
		int i = 10;
		int j = 20;
		int k = 10;
		
		if(i > j) {
			System.out.println("i가 j보다 큽니다.");
		}
			
		if(i < j) {
			System.out.println("i가 j보다 작습니다.");
		}
		
		if(i == j) { 
			System.out.println("i와 j는 동일합니다.");
		}

		
		System.out.println(">>> End <<<");
		
		
//		System.out.print("첫번째 숫자를 입력하세요 : ");
//		
//		Scanner scanner = new Scanner(System.in);		
//		
//		int num1 = scanner.nextInt();
//		
//		System.out.print("두번째 숫자를 입력하세요 : ");
//		
//		int num2 = scanner.nextInt();
//
//		System.out.println("");		
//		System.out.println("<Result>");		
//		
//		if(num1>num2) {
//			System.out.println("첫번째 숫자가 두번째 숫자보다 큽니다.");
//		}
//		
//		if(num1<num2) {
//			System.out.println("첫번째 숫자가 두번째 숫자보다 작습니다.");
//		}
//		
//		if(num1==num2) {
//			System.out.println("첫번째 숫자가 두번째 숫자와 같습니다.");
//		}
				
		
	}

}
