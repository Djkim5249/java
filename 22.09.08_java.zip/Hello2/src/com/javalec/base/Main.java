package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Good Morning! 출력하기
		System.out.println("Good Morning!");
//		Good Afternoon! 출력하기
		System.out.println("Good Afternoon!");
//		Good Evening! 출력하기
		System.out.println("Good Evening!");
//		한칸띄기
		System.out.println("");
//		반갑습니다. 출력하기
		System.out.println("반갑습니다.");
		System.out.println("<<<<<>>>>>");
	}

}
