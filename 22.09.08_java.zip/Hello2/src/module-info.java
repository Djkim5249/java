module Hello2 {
}