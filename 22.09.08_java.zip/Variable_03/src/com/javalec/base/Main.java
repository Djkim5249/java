package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i1 = 10;
		double d1 = i1;
		System.out.println("d1의 데이터는 " + d1 + " 입니다.");
		
		double d2 = 10.8;
		int i2 = (int) d2;
		System.out.println("i2의 데이터는 " + i2 + " 입니다.");
		
		
	}

}
